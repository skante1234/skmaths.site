#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Génère toute la structure du site skmaths.fr (pages + arborescence downloads/)."""
import os
from pathlib import Path

ROOT = Path("/home/claude/skmaths-structure")
ROOT.mkdir(exist_ok=True, parents=True)

# ============================================================================
# STRUCTURE DES NIVEAUX
# ============================================================================
NIVEAUX = {
    # niveau_id : (label affiché, description courte, liste des sections/branches)
    # Format section : (id_folder, label)
    "sixieme":    ("6ᵉ",  "Nombres entiers, décimaux, géométrie, initiation.", None),
    "cinquieme":  ("5ᵉ",  "Fractions, proportionnalité, triangles, angles.", None),
    "quatrieme":  ("4ᵉ",  "Puissances, calcul littéral, Pythagore, statistiques.", None),
    "troisieme":  ("3ᵉ",  "Racines, Thalès, trigonométrie, préparation Brevet.", None),
    "seconde":    ("Seconde", "Tronc commun. Bases solides avant la spécialité.", None),
    "premiere":   ("Première", "Trois voies : spécialité, tronc commun, séries technologiques.", [
        ("spe",           "Spécialité mathématiques"),
        ("tronc-commun",  "Tronc commun (enseignement scientifique)"),
        ("stmg",          "STMG — Sciences et technologies du management"),
        ("std2a",         "STD2A — Sciences et technologies du design"),
    ]),
    "terminale":  ("Terminale", "Année du Bac. Spécialité, options et séries technologiques.", [
        ("spe",             "Spécialité mathématiques"),
        ("expertes",        "Option Mathématiques Expertes"),
        ("complementaires", "Option Mathématiques Complémentaires"),
        ("stmg",            "STMG — Sciences et technologies du management"),
        ("std2a",           "STD2A — Sciences et technologies du design"),
    ]),
    "prepas":     ("Prépas", "MPSI, PCSI, ECG. Méthodes de concours.", None),
}

# Sections communes à chaque page finale (cours, exercices, fiches, automatismes)
DOC_TYPES = [
    ("cours",           "Fiches de cours",     "Le cours structuré, définitions, théorèmes, démonstrations."),
    ("exercices",       "Fiches d'exercices",  "Exercices classés par difficulté, corrigés détaillés."),
    ("fiches-revision", "Fiches de révision",  "Synthèses avant contrôle ou examen : l'essentiel en 1 page."),
    ("automatismes",    "Automatismes",        "Calcul mental, réflexes, entraînement quotidien."),
]

# ============================================================================
# TEMPLATE HTML
# ============================================================================
BASE_CSS = "skmaths.css"    # ton CSS existant, on s'y appuie

def head(title):
    return f"""<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{title} — SKmaths</title>
  <meta name="description" content="{title} · SKmaths — cours, exercices, fiches de révision et automatismes en mathématiques.">
  <link rel="stylesheet" href="{BASE_CSS}">
  <style>
    /* --- Styles locaux : listes de téléchargement et sections niveau --- */
    .niveau-hero {{ padding: 3rem 1.5rem 2rem; text-align: center; border-bottom: 1px solid #dfd5bf; }}
    .niveau-hero .eyebrow {{
      font-family: 'JetBrains Mono', monospace; font-size: 0.75rem;
      letter-spacing: 0.18em; text-transform: uppercase; color: #b87a2c; margin-bottom: 0.6rem;
    }}
    .niveau-hero h1 {{ font-family: 'Fraunces', 'EB Garamond', serif; font-size: 3rem; color: #1a1d2e; margin: 0.3rem 0; }}
    .niveau-hero p.intro {{ font-style: italic; color: #5a5d6e; max-width: 640px; margin: 0.8rem auto 0; }}
    .niveau-content {{ max-width: 800px; margin: 2.5rem auto; padding: 0 1.5rem; }}
    .section-doc {{ margin-bottom: 3rem; }}
    .section-doc h2 {{
      font-family: 'Fraunces', serif; font-size: 1.8rem; color: #1a1d2e;
      border-bottom: 2px solid #b87a2c; padding-bottom: 0.4rem; margin-bottom: 0.4rem;
    }}
    .section-doc .desc {{ font-style: italic; color: #5a5d6e; margin: 0 0 1rem; font-size: 0.95rem; }}
    .liste-docs {{ list-style: none; padding: 0; margin: 0; }}
    .liste-docs li {{ margin-bottom: 0.6rem; }}
    .liste-docs a {{
      display: flex; align-items: center; gap: 0.8rem; padding: 0.9rem 1.1rem;
      background: #fbf6ec; border: 1px solid #dfd5bf; border-radius: 4px;
      color: #1a1d2e; text-decoration: none; transition: all 0.15s;
    }}
    .liste-docs a:hover {{ background: #f4ede0; transform: translateX(4px); border-color: #b87a2c; }}
    .liste-docs .titre {{ flex-grow: 1; }}
    .liste-docs .format {{
      font-family: 'JetBrains Mono', monospace; font-size: 0.7rem;
      letter-spacing: 0.05em; padding: 0.15rem 0.5rem;
      background: #a83246; color: white; border-radius: 3px;
    }}
    .vide {{
      background: #fbf6ec; border: 1px dashed #dfd5bf; border-radius: 4px;
      padding: 1.2rem 1.4rem; color: #5a5d6e; font-style: italic;
    }}
    /* --- Cartes des branches (hub Première / Terminale / Collège) --- */
    .branches-grid {{ display: grid; grid-template-columns: repeat(auto-fit,minmax(260px,1fr)); gap: 1.2rem; }}
    .branche-card {{
      display: block; background: #fbf6ec; border: 1px solid #dfd5bf;
      padding: 1.6rem; border-radius: 4px; text-decoration: none; color: #1a1d2e;
      transition: all 0.2s;
    }}
    .branche-card:hover {{ background: #f4ede0; transform: translateY(-2px); border-color: #b87a2c; }}
    .branche-card .num {{
      font-family: 'JetBrains Mono', monospace; color: #b87a2c; font-size: 0.85rem; letter-spacing: 0.1em;
    }}
    .branche-card h3 {{ font-family: 'Fraunces', serif; font-size: 1.35rem; margin: 0.3rem 0 0.4rem; }}
    .branche-card p {{ margin: 0; color: #5a5d6e; font-size: 0.92rem; }}
    .retour {{ display: inline-block; margin: 2rem auto 0; color: #2c4870; text-decoration: none; font-size: 0.9rem; }}
    .retour:hover {{ text-decoration: underline; }}
    footer.simple {{ text-align: center; padding: 2rem 1rem; border-top: 1px solid #dfd5bf; margin-top: 3rem; color: #5a5d6e; font-size: 0.85rem; }}
  </style>
</head>
<body>
"""

FOOTER = """
  <footer class="simple">
    <a href="/" class="retour">← Retour à l'accueil</a>
    <p style="margin-top:1rem">© 2026 SKmaths — S. Kanté</p>
  </footer>
</body>
</html>
"""

def hero(eyebrow, titre, desc):
    return f"""
  <section class="niveau-hero">
    <div class="eyebrow">{eyebrow}</div>
    <h1>{titre}</h1>
    <p class="intro">{desc}</p>
  </section>
"""

def section_doc_html(niveau_folder, doc_id, doc_label, doc_desc, sample_files=None):
    """Génère une section de type de document. Si sample_files, insère les liens."""
    if sample_files:
        items = "\n".join(
            f'      <li><a href="/downloads/{niveau_folder}/{doc_id}/{f}" download>'
            f'<span class="titre">{lab}</span><span class="format">PDF</span></a></li>'
            for f, lab in sample_files
        )
        list_html = f'<ul class="liste-docs">\n{items}\n    </ul>'
    else:
        list_html = '<div class="vide">Bientôt disponible. Cette section accueillera vos documents à télécharger.</div>'
    return f"""
    <div class="section-doc">
      <h2>{doc_label}</h2>
      <p class="desc">{doc_desc}</p>
      {list_html}
    </div>
"""

# ============================================================================
# GÉNÉRATION DES PAGES SIMPLES (sans branches)
# ============================================================================
def generer_page_simple(niveau_id, label, desc, folder_path, sample=None):
    """Page niveau standard avec 4 sections cours/exercices/fiches/automatismes."""
    html = head(label)
    html += hero(f"Niveau · {label}", label, desc)
    html += '  <main class="niveau-content">\n'
    for doc_id, doc_label, doc_desc in DOC_TYPES:
        # Injection d'exemples uniquement pour Seconde (fichiers existants)
        sf = None
        if sample and doc_id in sample:
            sf = sample[doc_id]
        html += section_doc_html(folder_path, doc_id, doc_label, doc_desc, sf)
    html += "  </main>\n"
    html += FOOTER
    return html

# ============================================================================
# GÉNÉRATION DES HUBS (Première, Terminale)
# ============================================================================
def generer_hub(niveau_id, label, desc, branches):
    """Page hub qui liste les branches."""
    html = head(label)
    html += hero(f"Niveau · {label}", label, desc)
    html += '  <main class="niveau-content">\n'
    html += '    <div class="branches-grid">\n'
    for i, (branch_id, branch_label) in enumerate(branches, 1):
        num = f"0{i}" if i < 10 else str(i)
        html += f"""      <a class="branche-card" href="/{niveau_id}-{branch_id}.html">
        <div class="num">{num}</div>
        <h3>{branch_label}</h3>
        <p>Cours, exercices, fiches de révision et automatismes.</p>
      </a>
"""
    html += "    </div>\n"
    html += "  </main>\n"
    html += FOOTER
    return html

# ============================================================================
# GÉNÉRATION DES BRANCHES (premiere-spe, terminale-expertes, etc.)
# ============================================================================
def generer_page_branche(niveau_id, niveau_label, branch_id, branch_label):
    """Page d'une branche : contient les 4 types de documents."""
    folder_path = f"{niveau_id}/{branch_id}"
    html = head(f"{niveau_label} — {branch_label}")
    html += hero(f"{niveau_label} · {branch_label}", branch_label, "")
    html += f'  <main class="niveau-content">\n'
    html += f'    <p style="text-align:center;margin-bottom:2rem"><a href="/{niveau_id}.html" style="color:#2c4870">← Retour aux voies de {niveau_label}</a></p>\n'
    for doc_id, doc_label, doc_desc in DOC_TYPES:
        html += section_doc_html(folder_path, doc_id, doc_label, doc_desc, None)
    html += "  </main>\n"
    html += FOOTER
    return html

# ============================================================================
# GÉNÉRATION EFFECTIVE
# ============================================================================
site_dir = ROOT / "site"
downloads_dir = ROOT / "downloads"
site_dir.mkdir(exist_ok=True)
downloads_dir.mkdir(exist_ok=True)

generated_pages = []
generated_folders = []

# Exemples pour Seconde (fichiers existants dans son GitHub)
SAMPLE_SECONDE = {
    "automatismes": [("automatismes-enonce.pdf", "Automatismes — énoncés")],
    "fiches-revision": [("fiche-revision.pdf", "Fiche de révision")],
}

for niveau_id, (label, desc, branches) in NIVEAUX.items():
    if branches is None:
        # Page simple
        sample = SAMPLE_SECONDE if niveau_id == "seconde" else None
        html = generer_page_simple(niveau_id, label, desc, niveau_id, sample)
        (site_dir / f"{niveau_id}.html").write_text(html, encoding="utf-8")
        generated_pages.append(f"{niveau_id}.html")
        # Dossiers de téléchargement
        for doc_id, _, _ in DOC_TYPES:
            d = downloads_dir / niveau_id / doc_id
            d.mkdir(parents=True, exist_ok=True)
            (d / ".gitkeep").touch()
            generated_folders.append(str(d.relative_to(ROOT)))
    else:
        # Page hub
        html = generer_hub(niveau_id, label, desc, branches)
        (site_dir / f"{niveau_id}.html").write_text(html, encoding="utf-8")
        generated_pages.append(f"{niveau_id}.html")
        # Pages branches
        for branch_id, branch_label in branches:
            branch_html = generer_page_branche(niveau_id, label, branch_id, branch_label)
            (site_dir / f"{niveau_id}-{branch_id}.html").write_text(branch_html, encoding="utf-8")
            generated_pages.append(f"{niveau_id}-{branch_id}.html")
            for doc_id, _, _ in DOC_TYPES:
                d = downloads_dir / niveau_id / branch_id / doc_id
                d.mkdir(parents=True, exist_ok=True)
                (d / ".gitkeep").touch()
                generated_folders.append(str(d.relative_to(ROOT)))

# ============================================================================
# PAGE COLLÈGE (hub des 4 niveaux collège)
# ============================================================================
college_html = head("Collège")
college_html += hero("Parcours · Collège", "Collège", "De la 6ᵉ à la 3ᵉ. Préparation au Brevet des collèges.")
college_html += '  <main class="niveau-content">\n    <div class="branches-grid">\n'
for i, (niv, lab) in enumerate([("sixieme","6ᵉ"),("cinquieme","5ᵉ"),("quatrieme","4ᵉ"),("troisieme","3ᵉ")],1):
    college_html += f"""      <a class="branche-card" href="/{niv}.html">
        <div class="num">0{i}</div>
        <h3>{lab}</h3>
        <p>Cours, exercices, fiches et automatismes.</p>
      </a>
"""
college_html += "    </div>\n  </main>\n" + FOOTER
(site_dir / "college.html").write_text(college_html, encoding="utf-8")
generated_pages.append("college.html")

# ============================================================================
# RÉCAPITULATIF
# ============================================================================
print(f"✓ {len(generated_pages)} pages HTML générées :")
for p in sorted(generated_pages):
    print(f"    site/{p}")
print(f"\n✓ {len(generated_folders)} dossiers de téléchargement créés")
print(f"    (racine : downloads/)")
