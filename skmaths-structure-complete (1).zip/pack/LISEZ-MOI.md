# Structure complète skmaths.fr

## Contenu du zip

### 📁 site/ — Les 18 pages HTML prêtes à l'emploi
À uploader à la racine de ton dépôt GitHub `skmaths.site`.

### 📁 downloads/ — L'arborescence des 60 dossiers de téléchargement
À uploader dans le dépôt (chaque dossier contient un fichier `.gitkeep` invisible qui force sa création sur GitHub).

### 📁 sources/ — Sources LaTeX et Python
- `guide-structure-site.tex` — sources du guide PDF
- `identite-prof.sty` — stub, remplace par ton vrai fichier
- `gen_site.py` — regénère les pages HTML si tu veux modifier la structure
- `fonts/` — polices Cormorant Garamond + JetBrains Mono (pour compiler le PDF)

## Ordre d'utilisation

Lis d'abord le fichier `guide-structure-site.pdf` (livré séparément).
Il te guide étape par étape sur 7 jours.

## Régénérer les HTML (optionnel)

```
cd sources/
python3 gen_site.py
```
Les pages seront dans `skmaths-structure/site/`.
